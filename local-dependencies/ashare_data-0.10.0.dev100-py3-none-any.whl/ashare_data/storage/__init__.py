"""Storage functionality."""
