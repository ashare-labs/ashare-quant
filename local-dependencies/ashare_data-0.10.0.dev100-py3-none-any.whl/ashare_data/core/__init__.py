"""Core functionality."""
