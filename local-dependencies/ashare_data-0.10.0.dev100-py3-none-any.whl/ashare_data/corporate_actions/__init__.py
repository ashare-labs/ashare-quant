"""Corporate actions functionality."""
