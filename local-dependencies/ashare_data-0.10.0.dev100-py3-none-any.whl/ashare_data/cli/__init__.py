"""Explicit import / validate / publish / query operations. JSON in and out."""

from __future__ import annotations

import argparse
import json
import sys
from decimal import Decimal
from datetime import date, datetime
from pathlib import Path

from ashare_data import __version__
from ashare_data.core.model import DataError, require
from ashare_data.storage.immutable import Store
from ashare_data.market.client import Client, capabilities
from ashare_data.core.coverage import CoverageContract
from ashare_data.core.query_limits import QueryLimits


def json_value(value):
    if isinstance(value, (date, datetime)):
        return value.isoformat()
    if isinstance(value, Decimal):
        return format(value, "f")
    raise TypeError(type(value).__name__)


def read_json(path):
    path = Path(path)
    require(
        path.is_file() and path.stat().st_size <= 64 * 1024 * 1024,
        "BOUNDED_IMPORT",
        "只允许最大 64 MiB 的本地 JSON 文件",
    )
    return json.loads(path.read_text(encoding="utf-8"))


def parser():
    p = argparse.ArgumentParser(
        prog="ashare-data", description="A数达：行情查询、本地日线维护与离线研究"
    )
    p.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    p.add_argument("--store", help="高级离线快照目录；直接行情查询无需此参数")
    sub = p.add_subparsers(dest="command", required=True)
    sub.add_parser("product", help="Configured local product queries, including registered minute sources")
    sub.add_parser("cmes", help="Offline CMES file import and isolated candidate queries")
    sub.add_parser("free-updates", help="Frozen CMES menu public-source sample updates and acceptance")
    sub.add_parser("native-macro", help="Prepare native macro candidates and query pinned releases")
    sub.add_parser("daily-update", help="Recoverable daily all-market public-source updates")
    from ashare_data.cli.zzshare import add_parsers as add_zzshare_parsers

    add_zzshare_parsers(sub)
    from ashare_data.cli.local_daily import add_parser as add_local_daily_parser

    add_local_daily_parser(sub)
    from ashare_data.cli.corporate_actions import add_parser as add_corporate_history_parser

    add_corporate_history_parser(sub)
    for name in ("init", "capabilities", "snapshots", "recover"):
        sub.add_parser(name)
    price = sub.add_parser("price", help="直接从公开源获取行情，无需初始化")
    price.add_argument("security", nargs="+")
    price.add_argument("--start")
    price.add_argument("--end")
    price.add_argument("--count", type=int)
    price.add_argument(
        "--frequency", choices=["daily", "1d", "1m", "minute", "5m"], default="daily"
    )
    price.add_argument("--fields", nargs="+")
    price.add_argument("--fq", choices=["none", "pre", "post"], default="none")
    price.add_argument("--strict", action="store_true")
    price.add_argument("--as-of", help="独立策略时钟；不改变 end 标签过滤语义；仅读固定缓存")
    price.add_argument(
        "--visibility", choices=["assumed", "received", "verified"], default="verified"
    )
    price.add_argument("--require-complete", action="store_true")
    price.add_argument("--require-fresh", action="store_true")
    price.add_argument("--require-tradable", action="store_true")
    price.add_argument("--require-final", action="store_true")
    price.add_argument("--coverage-contract", help="A数达本地证据契约 JSON；不从缺 bar 推测状态")
    coverage = sub.add_parser("live-coverage", help="检查声明日历/session/status 下的标签覆盖")
    coverage.add_argument("security")
    coverage.add_argument("--start", required=True)
    coverage.add_argument("--end", required=True)
    coverage.add_argument("--frequency", choices=["daily", "1m", "5m"], default="1m")
    coverage.add_argument("--coverage-contract")
    state = sub.add_parser(
        "trading-status", help="仅读本地事实契约，判断休市/午休/停牌/可交易/未知"
    )
    state.add_argument("security")
    state.add_argument("--as-of", required=True)
    state.add_argument("--coverage-contract")
    acquire = sub.add_parser("acquire-price", help="显式刷新一个有限源窗口；无历史分页或造数补齐")
    acquire.add_argument("security")
    acquire.add_argument("--start", required=True)
    acquire.add_argument("--end", required=True)
    acquire.add_argument("--frequency", choices=["daily", "1m", "5m"], default="1m")
    acquire.add_argument("--coverage-contract")
    reconcile = sub.add_parser("reconcile-day", help="单股单日分钟与当前日快照量额诊断")
    reconcile.add_argument("security")
    reconcile.add_argument("--date", required=True)
    files = sub.add_parser("reconcile-files", help="离线对账固定新浪原文，不采集或修正行情")
    files.add_argument("security")
    files.add_argument("--date", required=True)
    files.add_argument("--one-minute", required=True)
    files.add_argument("--five-minute", required=True)
    files.add_argument("--quote", required=True)
    info = sub.add_parser("security", help="查询显式证券的当前名称/代码")
    info.add_argument("security")
    days = sub.add_parser("trade-days", help="查询上交所当前发布年度交易日")
    days.add_argument("--start")
    days.add_argument("--end")
    days.add_argument("--count", type=int)
    for live in (price, info, days, coverage, acquire, reconcile, state):
        live.add_argument("--cache", help="可选缓存目录")
        live.add_argument("--cache-mode", choices=["prefer", "only", "refresh"], default="prefer")
        live.add_argument("--timeout", type=float, default=15)
    imp = sub.add_parser("import", help="高级功能：从本地 JSON 导入离线快照")
    imp.add_argument("bundle")
    v = sub.add_parser("validate")
    v.add_argument("--batch", action="append", required=True)
    v.add_argument("--requirements", required=True, help="覆盖要求 JSON 列表")
    v.add_argument("--policy", choices=["observed", "synthetic", "research"], default="observed")
    pub = sub.add_parser("publish")
    pub.add_argument("--report", required=True)
    q = sub.add_parser("query")
    q.add_argument("--snapshot", required=True)
    q.add_argument(
        "dataset",
        choices=[
            "bars",
            "coverage",
            "instruments",
            "calendar",
            "sessions",
            "lineage",
            "quality",
            "corporate-actions",
            "adjustment-factors",
        ],
    )
    q.add_argument("--symbol", action="append")
    q.add_argument("--start")
    q.add_argument("--end")
    q.add_argument("--as-of")
    q.add_argument("--quality", choices=["observed", "synthetic", "research"], default="observed")
    q.add_argument(
        "--allow-partial", action="store_true", help="仅 bars：明确返回缺口，仍不允许来源冲突"
    )
    for name in ("research-snapshots", "research-recover"):
        sub.add_parser(name)
    pf = sub.add_parser(
        "research-preflight", help="离线逐证券/日期/用途研究输入与缺口；不授予执行许可"
    )
    pf.add_argument("--request", required=True, help="显式固定来源ID与可选本地store路径的JSON")
    pf.add_argument(
        "--require-complete",
        action="store_true",
        help="所需研究字段有缺口则拒绝；不升级PIT或执行资格",
    )
    ri = sub.add_parser("research-import", help="封存旧本地 Bao 原价日线；接收时间保持未知")
    ri.add_argument("paths", nargs="+")
    ri.add_argument("--calendar")
    rd = sub.add_parser("research-describe", help="离线重开并校验持久研究描述符")
    rd.add_argument("--dataset", required=True)
    for name in ("research-fetch", "research-price"):
        rp = sub.add_parser(
            name, help="显式拉取封存" if name == "research-fetch" else "仅查询固定本地版本"
        )
        rp.add_argument("security", nargs="+")
        rp.add_argument("--start")
        rp.add_argument("--end")
        rp.add_argument("--count", type=int)
        rp.add_argument(
            "--frequency", choices=["daily", "1d", "1m", "minute", "5m"], default="daily"
        )
        if name == "research-fetch":
            rp.add_argument("--timeout", type=float, default=15)
        else:
            rp.add_argument("--dataset", required=True)
            rp.add_argument("--fields", nargs="+")
            rp.add_argument("--as-of")
            rp.add_argument(
                "--visibility", choices=["verified", "assumed", "received"], default="verified"
            )
            for flag in ("complete", "fresh", "final", "tradable"):
                rp.add_argument("--require-" + flag, action="store_true")
    for query_parser in (price, rp):  # rp is the offline research-price parser.
        query_parser.add_argument(
            "--allow-partial", action="store_true", help="返回可用记录及逐证券缺口/错误"
        )
        query_parser.add_argument("--max-securities", type=int, default=10)
        query_parser.add_argument("--max-count", type=int, default=1000)
        query_parser.add_argument("--max-observation-rows", type=int, default=100000)
    bf = sub.add_parser("baostock-fetch", help="显式查询匿名免费源并封存请求证据")
    bf.add_argument(
        "kind", choices=["daily", "daily_status", "daily_preclose", "minute", "basic", "calendar"]
    )
    bf.add_argument("--frequency", choices=["daily", "5m", "15m", "30m", "60m"])
    bf.add_argument("--security")
    bf.add_argument("--start")
    bf.add_argument("--end")
    bf.add_argument("--sdk-path", help="已有官方0.9.4 SDK根目录；不自动安装")
    bf.add_argument("--timeout", type=float, default=15)
    bq = sub.add_parser("baostock-query", help="离线查询固定BaoStock证据版本")
    bq.add_argument(
        "dataset",
        choices=[
            "price",
            "statuses",
            "preclose",
            "calendar",
            "calendar-links",
            "security",
            "trade-days",
            "descriptor",
            "quality",
            "coverage",
            "lineage",
        ],
    )
    bq.add_argument("--capture", required=True)
    bq.add_argument("--as-of")
    bq.add_argument(
        "--visibility", choices=["received", "verified", "source_label"], default="received"
    )
    bq.add_argument("--end", help="分钟源标签上限，含秒和时区；非发布/闭合时间")
    bq.add_argument("--end-exclusive", action="store_true", help="排除--end恰好相等的标签")
    bq.add_argument(
        "--require-known",
        action="store_true",
        help="仅日状态、源preclose或源日历：任一未知字段即拒绝；不授予交易许可",
    )
    bq.add_argument("--dates", nargs="+", help="仅calendar-links：固定capture内的开市锚点日期")
    bi = sub.add_parser("baostock-import", help="显式离线导入已捕获的原始BaoStock回执")
    bi.add_argument("directory")
    sub.add_parser("baostock-snapshots")
    sub.add_parser("baostock-recover")
    di = sub.add_parser("facts-import-facts", help="离线封存已审阅的固定FACTS证据包")
    di.add_argument("directory")
    dc = sub.add_parser("facts-compose", help="组合固定价格和事实版本，不授予执行许可")
    dc.add_argument("--price", required=True)
    dc.add_argument("--facts", required=True)
    dq = sub.add_parser("facts-query", help="固定FACTS组合的离线typed事实和阻断诊断")
    dq.add_argument(
        "dataset",
        choices=[
            "descriptor",
            "instrument",
            "rules",
            "bars",
            "calendar",
            "statuses",
            "events",
            "event-coverage",
            "limit-candidates",
            "prev-close-candidates",
            "coverage",
            "lineage",
            "quality",
            "admission",
            "owner-receipt",
        ],
    )
    dq.add_argument("--dataset", dest="dataset_id", required=True)
    sub.add_parser("facts-snapshots")
    sub.add_parser("facts-recover")
    bc = sub.add_parser("conditional-compose", help="显式接受三个假设并创建独立条件研究组合")
    bc.add_argument("--strict", required=True)
    bc.add_argument("--mode", required=True, choices=["conditional_research"])
    bc.add_argument("--assumption", action="append", required=True)
    bq = sub.add_parser("conditional-query", help="离线条件模型投影；不授予后端执行许可")
    bq.add_argument(
        "dataset",
        choices=[
            "descriptor",
            "profile",
            "admission",
            "owner-receipt",
            "instrument",
            "rules",
            "bars",
            "calendar",
            "statuses",
            "modeled-events",
            "price-limits",
            "adjusted-prev-close",
        ],
    )
    bq.add_argument("--dataset", dest="dataset_id", required=True)
    bq.add_argument("--mode", required=True, choices=["conditional_research"])
    bq.add_argument("--date")
    bq.add_argument("--call", help="完整AD08参数tuple JSON文件")
    sub.add_parser("conditional-snapshots")
    sub.add_parser("conditional-recover")
    bl = sub.add_parser("conditional-listing", help="显式绑定有界上市状态契约；不授予执行许可")
    bl.add_argument("operation", choices=["contract", "status", "successor"])
    bl.add_argument("--dataset", dest="dataset_id", required=True)
    bl.add_argument("--mode", required=True, choices=["conditional_research"])
    bl.add_argument("--contract", dest="contract_sha256")
    bl.add_argument("--call", help="完整有界请求JSON；须含消费方context_sha256")
    portable = sub.add_parser("portable", help="固定有限PORTABLE公开契约；离线，不授执行许可")
    portable.add_argument(
        "action",
        choices=[
            "import",
            "profiles",
            "query",
            "canonical",
            "snapshots",
            "recover",
            "import-sources",
            "import-component",
            "component",
            "validate",
            "compose",
            "report",
            "export",
        ],
    )
    portable.add_argument(
        "--request",
        required=True,
        help="严格JSON请求文件；schema见 docs/research-packages.md#cli",
    )
    li = sub.add_parser("listing-import", help="离线封存固定审阅的上市年份证据包")
    li.add_argument("directory")
    lq = sub.add_parser("listing-query", help="仅固定单字段事实，不授予历史资格或执行许可")
    lq.add_argument("operation", choices=["value", "descriptor", "lineage", "validate"])
    lq.add_argument("--snapshot", required=True)
    lq.add_argument("--security")
    lq.add_argument("--date")
    lq.add_argument("--field")
    lq.add_argument("--visibility")
    lq.add_argument("--knowledge-at")
    sub.add_parser("listing-snapshots")
    sub.add_parser("listing-recover")
    return p


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    from ashare_data.core.consumer_policy import guard_arguments

    try:
        guard_arguments(argv, commands={"product", "capabilities"})
    except DataError as exc:
        print(json.dumps({"error": exc.as_dict()}, ensure_ascii=False), file=sys.stderr)
        return 2
    if argv[:1] == ["native-macro"]:
        from ashare_data.cli.native_macro import main as native_macro_main
        return native_macro_main(argv[1:])
    if argv[:1] == ["free-updates"]:
        from ashare_data.cli.free_updates import main as free_updates_main

        return free_updates_main(argv[1:])
    if argv[:1] == ["daily-update"]:
        from ashare_data.cli.daily_increment import main as daily_increment_main

        return daily_increment_main(argv[1:])
    if argv[:1] == ["cmes"]:
        from ashare_data.cli.cmes import main as cmes_main

        return cmes_main(argv[1:])
    if argv[:1] == ["product"]:
        from ashare_data.product.__main__ import main as product_main

        return product_main(argv[1:])
    args = parser().parse_args(argv)
    try:
        if args.command == "corporate-history":
            from ashare_data.cli.corporate_actions import command

            result = command(args)
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 2 if result.get("ready_for_declared_date_model") is False else 0
        if args.command == "local-daily":
            from ashare_data.storage.local_daily import command

            print(json.dumps(command(args), ensure_ascii=False, indent=2))
            return 0
        if args.command == "reconcile-files":
            from ashare_data.market.turnover_diagnostics import MAX_BYTES, reconcile_sina_day

            def raw_file(name):
                path = Path(name)
                require(
                    path.is_file() and path.stat().st_size <= MAX_BYTES,
                    "BOUNDED_IMPORT",
                    "原文文件须存在且不超过2MiB",
                )
                with path.open("rb") as stream:
                    return stream.read(MAX_BYTES + 1)

            result = reconcile_sina_day(
                args.security,
                args.date,
                minute_body=raw_file(args.one_minute),
                five_minute_body=raw_file(args.five_minute),
                quote_body=raw_file(args.quote),
            )
            print(json.dumps(result, ensure_ascii=False, sort_keys=True))
            return 2  # Diagnostic completed; market completeness/authenticity is still unverified.
        if args.command.startswith("zzshare-"):
            from ashare_data.cli.zzshare import dispatch as dispatch_zzshare

            result = dispatch_zzshare(args)
            print(json.dumps(result, ensure_ascii=False, sort_keys=True, default=json_value))
            return 0
        if args.command == "portable":
            from ashare_data.cli.portable import dispatch
            from ashare_data.research.portable_types import canonical_bytes, json_loads

            result = dispatch(args.store, args.action, json_loads(Path(args.request).read_bytes()))
            print(canonical_bytes(result).decode())
            return 2 if args.action == "validate" and result.get("status") == "BLOCKED" else 0
        if args.command in {
            "price",
            "security",
            "trade-days",
            "live-coverage",
            "acquire-price",
            "reconcile-day",
            "trading-status",
        }:
            contract_path = getattr(args, "coverage_contract", None)
            client = Client(
                cache=args.cache,
                cache_mode=args.cache_mode,
                timeout=args.timeout,
                coverage_contract=CoverageContract(read_json(contract_path))
                if contract_path
                else None,
            )
            if args.command == "price":
                client.query_limits = QueryLimits(
                    args.max_securities, args.max_count, args.max_observation_rows
                )
                frame = client.get_price(
                    args.security[0] if len(args.security) == 1 else args.security,
                    start_date=args.start,
                    end_date=args.end,
                    count=args.count,
                    frequency=args.frequency,
                    fields=args.fields,
                    fq=None if args.fq == "none" else args.fq,
                    strict=args.strict,
                    as_of=args.as_of,
                    visibility=args.visibility,
                    require_complete=args.require_complete,
                    require_fresh=args.require_fresh,
                    require_final=args.require_final,
                    require_tradable=args.require_tradable,
                    allow_partial=args.allow_partial,
                )
                result = {
                    "rows": (frame.reset_index() if frame.index.name == "time" else frame).to_dict(
                        "records"
                    ),
                    "metadata": frame.attrs,
                }
            elif args.command == "live-coverage":
                result = client.coverage(
                    args.security, args.start, args.end, frequency=args.frequency
                )
            elif args.command == "trading-status":
                result = client.trading_status(args.security, as_of=args.as_of)
            elif args.command == "acquire-price":
                result = client.acquire_price(
                    args.security, args.start, args.end, frequency=args.frequency
                )
            elif args.command == "reconcile-day":
                result = client.reconcile_day(args.security, args.date)
            elif args.command == "security":
                result = client.get_security_info(args.security)
            else:
                result = {
                    "days": client.get_trade_days(args.start, args.end, args.count),
                    "source": "SSE current published annual schedule",
                }
        elif args.command == "capabilities" and args.store is None:
            result = capabilities()
        elif args.command == "init":
            require(args.store is not None, "STORE_REQUIRED", "高级快照操作须指定 --store")
            store = Store.init(args.store)
            result = {"store": str(store.root), "initialized": True}
        else:
            require(args.store is not None, "STORE_REQUIRED", "高级快照操作须指定 --store")
            store = Store(args.store)
            if args.command in {"capabilities", "snapshots", "recover"}:
                result = getattr(store, args.command)()
            elif args.command == "listing-import":
                result = {"snapshot_id": store.import_listing_evidence(args.directory)}
            elif args.command == "listing-snapshots":
                result = store.listing_fact_snapshots()
            elif args.command == "listing-recover":
                result = store.recover_listing_facts()
            elif args.command == "listing-query":
                if args.operation == "value":
                    require(
                        args.security is not None and args.date is not None,
                        "LISTING_QUERY_ARGUMENT",
                        "value须提供security和date",
                    )
                    result = (
                        store.listing_fact(args.snapshot)
                        .get(
                            args.security,
                            args.date,
                            field=args.field if args.field is not None else "initial_listing_year",
                            visibility=args.visibility
                            if args.visibility is not None
                            else "posthoc",
                            knowledge_at=args.knowledge_at,
                        )
                        .to_dict()
                    )
                else:
                    require(
                        all(
                            x is None
                            for x in (
                                args.security,
                                args.date,
                                args.field,
                                args.visibility,
                                args.knowledge_at,
                            )
                        ),
                        "LISTING_QUERY_ARGUMENT",
                        "非value操作不接受字段查询参数",
                    )
                    value = getattr(store.listing_fact(args.snapshot), args.operation)()
                    result = (
                        [x.to_dict() for x in value]
                        if isinstance(value, tuple)
                        else value.to_dict()
                        if hasattr(value, "to_dict")
                        else value
                    )
            elif args.command == "research-preflight":
                result = store.preflight_research_request(
                    read_json(args.request), require_complete=args.require_complete
                ).to_dict()
            elif args.command == "facts-import-facts":
                result = {"facts_component_id": store.import_fact_component(args.directory)}
            elif args.command == "conditional-compose":
                result = {
                    "dataset_id": store.compose_conditional(
                        args.strict, mode=args.mode, assumption_ids=args.assumption
                    )
                }
            elif args.command == "conditional-snapshots":
                result = store.conditional_snapshots()
            elif args.command == "conditional-recover":
                result = store.recover_conditional()
            elif args.command == "conditional-query":
                require(
                    (args.date is not None) == (args.dataset == "price-limits")
                    and (args.call is not None) == (args.dataset == "adjusted-prev-close"),
                    "CONDITIONAL_QUERY_ARGUMENT",
                    "date仅且必须用于price-limits，call仅且必须用于adjusted-prev-close",
                )
                view = store.conditional(args.dataset_id, mode=args.mode)
                method = getattr(view, args.dataset.replace("-", "_"))
                value = (
                    method(args.date)
                    if args.date is not None
                    else (method(**read_json(args.call)) if args.call else method())
                )
                result = (
                    [x.to_dict() for x in value] if isinstance(value, tuple) else value.to_dict()
                )
            elif args.command == "conditional-listing":
                view = store.conditional(args.dataset_id, mode=args.mode)
                if args.operation == "contract":
                    require(
                        args.contract_sha256 is None and args.call is None,
                        "CONDITIONAL_LISTING_ARGUMENT",
                        "contract不接受查询参数",
                    )
                    result = view.listing_contract().to_dict()
                else:
                    require(
                        args.contract_sha256 is not None and args.call is not None,
                        "CONDITIONAL_LISTING_ARGUMENT",
                        "查询必须固定contract并提供完整call",
                    )
                    listing = view.listing(contract_sha256=args.contract_sha256)
                    result = getattr(listing, args.operation)(**read_json(args.call)).to_dict()
            elif args.command == "facts-compose":
                result = {"dataset_id": store.compose_facts(args.price, args.facts)}
            elif args.command == "facts-snapshots":
                result = store.facts_snapshots()
            elif args.command == "facts-recover":
                result = store.recover_facts()
            elif args.command == "facts-query":
                view = store.facts(args.dataset_id)
                method = {"events": "known_events"}.get(
                    args.dataset, args.dataset.replace("-", "_")
                )
                value = getattr(view, method)()
                result = (
                    [x.to_dict() for x in value] if isinstance(value, tuple) else value.to_dict()
                )
            elif args.command == "baostock-import":
                result = {"capture_id": store.import_baostock_capture(args.directory)}
            elif args.command == "baostock-fetch":
                from ashare_data.providers.baostock import BaoStockSource

                source = BaoStockSource(sdk_path=args.sdk_path, timeout=args.timeout)
                sid = source.fetch(
                    store,
                    kind=args.kind,
                    security=args.security,
                    start_date=args.start,
                    end_date=args.end,
                    frequency=args.frequency,
                )
                result = store.baostock(sid).descriptor()
                require(
                    result["status"] in {"research_rows", "empty_unknown"},
                    "SOURCE_REQUEST_FAILED",
                    "源响应未达到研究读取条件；失败证据已封存",
                    result,
                )
            elif args.command == "baostock-query":
                require(
                    not args.require_known or args.dataset in {"statuses", "preclose", "calendar"},
                    "INVALID_ARGUMENT",
                    "require-known仅适用于statuses/preclose/calendar",
                )
                require(
                    (args.dates is not None) == (args.dataset == "calendar-links"),
                    "INVALID_ARGUMENT",
                    "calendar-links必需dates；其他查询不接受dates",
                )
                require(
                    args.as_of is not None or args.visibility == "received",
                    "INVALID_ARGUMENT",
                    "visibility须与as-of同传",
                )
                require(
                    not args.end_exclusive or args.end is not None,
                    "INVALID_ARGUMENT",
                    "end-exclusive须与end同传",
                )
                view = store.baostock(args.capture)
                if args.end is not None:
                    view = view.at(
                        args.end, visibility="source_label", inclusive=not args.end_exclusive
                    )
                if args.as_of is not None:
                    view = view.at(args.as_of, visibility=args.visibility)
                method = {
                    "price": "get_price",
                    "statuses": "get_status",
                    "preclose": "get_preclose",
                    "calendar": "get_calendar",
                    "calendar-links": "get_calendar_links",
                    "security": "get_security_info",
                    "trade-days": "get_trade_days",
                }.get(args.dataset, args.dataset)
                if args.dataset == "calendar-links":
                    value = view.get_calendar_links(trading_dates=args.dates)
                elif args.dataset in {"statuses", "preclose", "calendar"}:
                    value = getattr(view, method)(require_known=args.require_known)
                else:
                    value = getattr(view, method)()
                result = value.to_dict() if hasattr(value, "to_dict") else value
            elif args.command == "baostock-snapshots":
                result = store.baostock_snapshots()
            elif args.command == "baostock-recover":
                result = store.recover_baostock()
            elif args.command == "research-snapshots":
                result = store.research_snapshots()
            elif args.command == "research-recover":
                result = store.recover_research()
            elif args.command == "research-import":
                result = {
                    "dataset_id": store.import_research(args.paths, calendar_path=args.calendar)
                }
            elif args.command == "research-fetch":
                result = {
                    "dataset_id": store.fetch_price(
                        args.security[0] if len(args.security) == 1 else args.security,
                        start_date=args.start,
                        end_date=args.end,
                        frequency=args.frequency,
                        count=args.count,
                        timeout=args.timeout,
                    )
                }
            elif args.command == "research-describe":
                result = store.research(args.dataset).descriptor()
            elif args.command == "research-price":
                view = store.research(args.dataset)
                require(
                    args.as_of is not None or args.visibility == "verified",
                    "INVALID_REQUEST",
                    "visibility须与as-of同传",
                )
                if args.as_of is not None:
                    view = view.at(args.as_of, visibility=args.visibility)
                result = view.get_price(
                    args.security[0] if len(args.security) == 1 else args.security,
                    start_date=args.start,
                    end_date=args.end,
                    frequency=args.frequency,
                    fields=args.fields,
                    count=args.count,
                    require_complete=args.require_complete,
                    require_fresh=args.require_fresh,
                    require_final=args.require_final,
                    require_tradable=args.require_tradable,
                    allow_partial=args.allow_partial,
                    query_limits=QueryLimits(
                        args.max_securities, args.max_count, args.max_observation_rows
                    ),
                ).to_dict()
            elif args.command == "import":
                result = {"batch_id": store.import_bundle(read_json(args.bundle))}
            elif args.command == "validate":
                result = store.validate(
                    args.batch, requirements=read_json(args.requirements), policy=args.policy
                )
            elif args.command == "publish":
                result = {"snapshot_id": store.publish(args.report)}
            else:
                with store.snapshot(args.snapshot) as view:
                    ds = args.dataset
                    supplied = {
                        k
                        for k, val in {
                            "symbol": args.symbol,
                            "start": args.start,
                            "end": args.end,
                            "as_of": args.as_of,
                            "allow_partial": args.allow_partial,
                        }.items()
                        if val
                    }
                    allowed = {
                        "bars": {"symbol", "start", "end", "as_of", "allow_partial"},
                        "coverage": {"symbol", "start", "end", "as_of"},
                        "calendar": {"start", "end"},
                        "sessions": {"start"},
                        "instruments": {"as_of"},
                    }
                    require(
                        supplied <= allowed.get(ds, set()),
                        "INVALID_REQUEST",
                        "当前 dataset 不支持该参数",
                    )
                    require(
                        ds in {"bars", "coverage"} or args.quality == "observed",
                        "INVALID_REQUEST",
                        "当前 dataset 不接受 quality",
                    )
                    if ds in {"bars", "coverage"}:
                        kw = {
                            "symbols": args.symbol,
                            "start": args.start,
                            "end": args.end,
                            "as_of": args.as_of,
                            "quality": args.quality,
                        }
                        if ds == "bars":
                            kw["strict"] = not args.allow_partial
                        result = getattr(view, ds)(**kw)
                    elif ds == "calendar":
                        result = view.calendar(args.start, args.end)
                    elif ds == "sessions":
                        result = view.sessions(args.start)
                    elif ds == "instruments":
                        result = view.instruments(as_of=args.as_of)
                    else:
                        result = getattr(view, ds.replace("-", "_"))()
        print(json.dumps(result, ensure_ascii=False, sort_keys=True, default=json_value))
        if args.command in {"facts-query", "conditional-query"} and args.dataset == "admission":
            return 0 if result["execution_permission"] else 2
        if args.command in {"live-coverage", "acquire-price", "reconcile-day", "trading-status"}:
            return (
                0
                if result.get(
                    {
                        "live-coverage": "complete",
                        "acquire-price": "requirements_met",
                        "reconcile-day": "accepted",
                        "trading-status": "tradable",
                    }[args.command]
                )
                else 2
            )
        return 0 if args.command != "validate" or result["passed"] else 2
    except DataError as exc:
        print(
            json.dumps({"error": exc.as_dict()}, ensure_ascii=False, default=json_value),
            file=sys.stderr,
        )
        return 2
    except (OSError, ValueError, TypeError) as exc:
        print(
            json.dumps(
                {"error": {"code": "INPUT_OR_IO_ERROR", "message": str(exc)}}, ensure_ascii=False
            ),
            file=sys.stderr,
        )
        return 2


if __name__ == "__main__":
    sys.exit(main())
