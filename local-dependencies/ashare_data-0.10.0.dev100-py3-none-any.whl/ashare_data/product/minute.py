"""Explicit registered minute sources. Reads never collect, repair, or fall back."""

import hashlib
import json
import re
from pathlib import Path

from ashare_data.core.model import DataError, digest, require, timestamp
from ashare_data.product.configuration import load_profile
from ashare_data.providers.neigezhu import NeigezhuMinuteView


class LocalMinuteProduct:
    """Portable deployment registry; only the selected source is opened and verified."""

    def __init__(self, deployment=None, *, profile="product"):
        self.entry, self.root, self.document, selected = load_profile(deployment, profile=profile)
        self.profile = profile
        self.market_release = selected.get("market_release")
        self.frozen_market_config = None
        if self.market_release is not None:
            from ashare_data.product.configuration import resolve

            # Resolve prices and references from the same loaded deployment.
            # A second file read could observe a different profile during cutover.
            self.frozen_market_config = resolve(
                self.entry, profile=profile,
                _loaded=(self.entry, self.root, self.document, selected),
            )
            self.market_release = {
                **self.market_release,
                **{key: self.frozen_market_config["market_release"][key]
                   for key in ("release_id", "manifest_sha256")},
            }
        self.default_source = selected.get("default_minute_source", "tdx")
        self.registry = selected.get("minute_sources", {})
        if self.frozen_market_config is not None:
            from ashare_data.product.market_release import open_release

            release = open_release(self.frozen_market_config)
            with release.metadata() as db:
                if db.execute(
                    "select 1 from sqlite_master where type='table' and name='release_contracts'"
                ).fetchone():
                    frozen = db.execute(
                        "select body from release_contracts where name='source_observation_readers'"
                    ).fetchone()
                    if frozen:
                        readers = json.loads(frozen[0])
                        # Audit files travel with a restored release. Resolve by the
                        # frozen content hash, not the former deployment location.
                        evidence = {v["sha256"]: v for v in release.manifest.get("evidence", [])}
                        for item in readers["minute_sources"].values():
                            for name in ("manifest", "review"):
                                binding = item.get(name)
                                if binding:
                                    require(
                                        binding["sha256"] in evidence,
                                        "PRODUCT_MINUTE_CONFIGURATION",
                                        "Frozen native audit evidence is absent from this release",
                                    )
                                    binding["path"] = str(
                                        release.verify(evidence[binding["sha256"]])
                                    )
                        self.registry = {**self.registry, **readers["minute_sources"]}
                        self.document["assets"].update(readers["assets"])
        require(
            isinstance(self.registry, dict),
            "PRODUCT_MINUTE_CONFIGURATION",
            "minute_sources must be a mapping",
        )

    def _path(self, value):
        target = Path(value).expanduser()
        return (target if target.is_absolute() else self.root / target).resolve()

    def _binding(self, source):
        require(
            isinstance(source, str) and source in self.registry,
            "PRODUCT_MINUTE_SOURCE_UNKNOWN",
            "Select a registered minute source; no fallback",
        )
        try:
            item = self.registry[source]
            reader = item["reader"]
            require(
                reader in {"tdx-session", "neigezhu-native"},
                "PRODUCT_MINUTE_CONFIGURATION",
                "Unsupported registered minute reader",
            )
            asset = self.document["assets"][item["asset"]]
            require(
                asset["kind"] == "reference",
                "PRODUCT_MINUTE_CONFIGURATION",
                "Minute readers require a read-only reference asset",
            )
            bindings = {
                "source": source,
                "asset": item["asset"],
                "reader": reader,
                "path": str(self._path(asset["path"])),
                "coverage": item["coverage"],
                "limits": item["limits"],
                "historical_pit": False,
                "strict_execution_admitted": False,
            }
            keys = ("manifest", "review") if reader == "neigezhu-native" else ("content",)
            for key in keys:
                evidence = item[key]
                require(
                    isinstance(evidence["sha256"], str)
                    and re.fullmatch(r"[a-f0-9]{64}", evidence["sha256"]),
                    "PRODUCT_MINUTE_CONFIGURATION",
                    "Evidence requires an external SHA256 pin",
                )
                bindings[key] = {
                    "path": str(self._path(evidence["path"]))
                    if key != "content"
                    else bindings["path"],
                    "sha256": evidence["sha256"],
                }
            if reader == "neigezhu-native":
                require(
                    item["asset"] == "minute-hf-download",
                    "PRODUCT_MINUTE_CONFIGURATION",
                    "The native reader uses the existing minute-hf-download asset",
                )
            return bindings
        except (KeyError, TypeError, ValueError) as exc:
            raise DataError(
                "PRODUCT_MINUTE_CONFIGURATION",
                "Invalid minute source registration",
                {"source": source, "reason": str(exc)},
            ) from exc

    def sources(self):
        rows = []
        if self.market_release is not None:
            selected = self.market_release
            path = self._path(self.document["assets"][selected["asset"]]["path"])
            from ashare_data.product.market_release import open_release, released_minute_sources

            frozen = open_release(self.frozen_market_config)
            source_map, canonical_series = released_minute_sources(frozen)
            rows = [
                {
                    "source": source,
                    "reader": "market-release",
                    "series_id": series,
                    "path": str(path),
                    "release_id": selected["release_id"],
                    "manifest_sha256": selected["manifest_sha256"],
                    "status": "registered_unopened",
                    "historical_pit": False,
                    "strict_execution_admitted": False,
                }
                for source, series in [("canonical", canonical_series[0]), *source_map.items()]
                if source != "neigezhu"
            ]
        for source in (
            ["neigezhu"]
            if self.market_release is not None and "neigezhu" in self.registry
            else self.registry
            if self.market_release is None
            else []
        ):
            try:
                rows.append({**self._binding(source), "status": "registered_unopened"})
            except DataError as exc:
                rows.append(
                    {"source": source, "status": "registration_error", "error": exc.as_dict()}
                )
        return {
            "schema": "ad-local-minute-sources.v1",
            "default_source": self.default_source,
            "market_release": self.market_release,
            "profile": self.profile,
            "data_root": str(self.root),
            "registry_sha256": digest(
                {
                    "data_root": str(self.root),
                    "sources": rows,
                    "default_source": self.default_source,
                }
            ),
            "sources": rows,
            "coverage_basis": "Registered audit scope; not a promise of every security/day",
            "query_shape": {"securities": "one requested security", "range": "inclusive, no fixed span or row ceiling"},
            "verification": "Selected content is checked on query; discovery does not scan raw files",
        }

    def prices(self, security, start, end, *, source="auto"):
        a, b = timestamp(start, minute=True), timestamp(end, minute=True)
        require(
            a <= b,
            "PRODUCT_MINUTE_QUERY_BOUND",
            "Start must not follow end",
        )
        standard = source == "auto"
        source = self.default_source if standard else source
        if self.market_release is not None and (
            source not in self.registry or source in {"canonical", "tdx", "free_stockdb"}
        ):
            from ashare_data.product.market_release import minute_prices

            return minute_prices(self.frozen_market_config, security, a, b, source)
        binding = self._binding(source)
        try:
            if binding["reader"] == "neigezhu-native":
                view = NeigezhuMinuteView(
                    entry=self.entry,
                    source_root=binding["path"],
                    manifest=binding["manifest"]["path"],
                    expected_manifest_sha256=binding["manifest"]["sha256"],
                    review=binding["review"]["path"],
                    expected_review_sha256=binding["review"]["sha256"],
                )
                require(
                    view.root == Path(binding["path"]),
                    "PRODUCT_MINUTE_CONFIGURATION",
                    "Deployment source changed while opening the reader",
                )
                result = view.get_price(security, mode="retrospective", start=a, end=b).to_dict()
            else:
                path = Path(binding["path"])
                raw = path.read_bytes()
                require(
                    hashlib.sha256(raw).hexdigest() == binding["content"]["sha256"],
                    "PRODUCT_MINUTE_INTEGRITY",
                    "Registered TDX session changed",
                )
                value = json.loads(raw)
                require(
                    value["schema"] == "ad-tdx-minute-session.v1",
                    "PRODUCT_MINUTE_INTEGRITY",
                    "Unexpected TDX session schema",
                )
                rows = [
                    row
                    for row in value["minute"]
                    if row["security"] == security
                    and a <= timestamp(row["source_label"], minute=True) <= b
                ]
                result = {
                    "rows": rows,
                    "report": {
                        "schema": "ad-tdx-session-read.v1",
                        "rows": len(rows),
                        "range_inclusive": [a.isoformat(), b.isoformat()],
                        "historical_pit": False,
                        "execution_admitted": False,
                        "native_labels_preserved": True,
                        "repaired_rows": 0,
                        "limits": binding["limits"],
                    },
                }
        except (OSError, ValueError, KeyError, TypeError) as exc:
            raise DataError(
                "PRODUCT_MINUTE_UNAVAILABLE",
                "Selected minute source is unavailable",
                {"source": source, "reason": str(exc)},
            ) from exc
        if standard:
            from ashare_data.product.minute_quality import standard_quote

            result["rows"] = [standard_quote(row) for row in result["rows"]]
            result["report"]["unavailable_rows"] = sum(
                bool(row.get("missing_fields")) for row in result["rows"]
            )
        return {
            "schema": "ad-local-minute-prices.v1",
            "source": source,
            "binding": binding,
            **result,
        }
